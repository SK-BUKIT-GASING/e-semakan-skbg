GitHub Pages demo e-Semakan SKBG (responsif telefon).
Upload index.html dan .nojekyll ke root repository semakan-skbg-demo.
Hanya demo tanpa sambungan kepada Google Sheets sebenar.
